package pageObjects;
import org.openqa.selenium.WebDriver;

public class landingPage {
    private WebDriver driver;
    // page url
    private static String PAGE_URL="https://www.imdb.com";

    public String getHomeUrl(){
        return "https://www.imdb.com";
    }

    public String menuButtonLocator(){
        return "div.ipc-button__text" ;
    }

    public String filterForninepointfiveshow(){
        return "(//tr/*[following-sibling::td[@class='ratingColumn imdbRating'][strong='9.5']])[2]";
    }

    public String topratedshowmenu(){
        return "a[href='/chart/toptv/?ref_=nv_tvv_250']";
    }


}
