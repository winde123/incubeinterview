package bindings;

import com.github.javafaker.Faker;
import org.junit.Assert;
import org.openqa.selenium.By;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.concurrent.TimeUnit;


import pageObjects.landingPage;

public class question2 {
    WebDriver driver;
    @Given("^that I am on the imdb website and click on the sign in button$")
    public void that_I_am_on_the_imdb_website_and_click_on_the_sign_in_button() throws Throwable {
        System.setProperty("webdriver.chrome.driver", "chromedriver");
        // WebDriverWait wait= new WebDriverWait(driver, 20);
        driver = new ChromeDriver();
        WebDriverWait waiter = new WebDriverWait(driver, 10);
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
        driver.get(new landingPage().getHomeUrl());
        driver.manage().window().maximize();
        driver.get("https://www.imdb.com/registration/signin?ref=nv_generic_lgin");
    }

    @When("^I click on create a new account$")
    public void i_click_on_create_a_new_account() throws Throwable {
        driver.findElement(By.cssSelector("a.list-group-item.create-account")).click();
    }

    @When("^I fill in the relevant details in the field and click the create account button$")
    public void i_fill_in_the_relevant_details_in_the_field_and_click_the_create_account_button() throws Throwable {
        Faker faker = new Faker();
        String username = faker.name().firstName().replaceAll("\\s+","");;
        String country =faker.address().country().replaceAll("\\s+","");
        driver.findElement(By.cssSelector("input[type='text']")).sendKeys(username);
        driver.findElement(By.cssSelector("input[type=email]")).sendKeys(country+"@gmail.com");
        driver.findElement(By.cssSelector("#ap_password")).sendKeys("testtest001");
        driver.findElement(By.cssSelector("#ap_password_check")).sendKeys("testtest001");
        driver.findElement(By.cssSelector("#continue")).click();
    }

    @Then("^I should be logged in.$")
    public void i_should_be_logged_in() throws Throwable {
        driver.manage().deleteAllCookies();
        driver.get("https://www.imdb.com/registration/signin?ref=nv_generic_lgin");
        driver.findElement(By.cssSelector("span.auth-provider-text")).click();
        driver.findElement(By.cssSelector("input[type=email]")).sendKeys("wrwan001@gmail.com");
        driver.findElement(By.cssSelector("#ap_password")).sendKeys("testtest001");
        driver.findElement(By.cssSelector("#signInSubmit")).click();
        Assert.assertEquals(driver.getCurrentUrl(),"https://www.imdb.com/?ref_=login");
        driver.quit();
    }
}
