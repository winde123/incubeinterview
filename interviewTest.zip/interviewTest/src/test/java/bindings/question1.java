package bindings;
import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.concurrent.TimeUnit;
import static org.junit.Assert.assertTrue;

import pageObjects.landingPage;

public class question1 {
    WebDriver driver;
    @Given("^that I am on the imdb website and click on the menu button$")
    public void that_I_am_on_the_imdb_website() throws Throwable {

        System.setProperty("webdriver.chrome.driver", "chromedriver");
        // WebDriverWait wait= new WebDriverWait(driver, 20);
        driver = new ChromeDriver();
        WebDriverWait waiter = new WebDriverWait(driver, 10);
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
        driver.get(new landingPage().getHomeUrl());
        driver.manage().window().maximize();
        driver.findElement(By.cssSelector(new landingPage().menuButtonLocator())).click();
    }

    @When("^I click on top rated shows$")
    public void i_click_on_top_rated_shows() throws Throwable {
        Actions actions = new Actions(driver);
        actions.doubleClick(driver.findElement(By.cssSelector(new landingPage().topratedshowmenu())));
        driver.get("https://www.imdb.com/chart/toptv/?ref_=nv_tvv_250");
    }


    @Then("^I get a list of shows with requisite imdb ratings$")
    public void i_get_a_list_of_shows_with_imdb_ratings() throws Throwable {
        assertTrue(driver.findElement(By.xpath(new landingPage().filterForninepointfiveshow())).isDisplayed());
        driver.quit();
    }
}
